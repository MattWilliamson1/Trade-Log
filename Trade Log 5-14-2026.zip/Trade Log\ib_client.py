"""
Interactive Brokers client wrapper using ib_insync.

Each public method connects, queries, and disconnects to avoid persistent
connections across Streamlit reruns. Falls back gracefully if IB is not
available or not configured.
"""

from __future__ import annotations

import datetime
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from typing import Any

_IB_AVAILABLE = False
try:
    import nest_asyncio
    nest_asyncio.apply()
    from ib_insync import IB, Stock, Option, Future, Contract, util  # type: ignore
    _IB_AVAILABLE = True
except ImportError:
    pass

_connect_lock = threading.Lock()


def is_available() -> bool:
    return _IB_AVAILABLE


class IBClient:
    """Short-lived IB connection: connect → query → disconnect."""

    def __init__(self, host: str = "127.0.0.1", port: int = 7497, client_id: int = 1):
        self.host      = host
        self.port      = int(port)
        self.client_id = int(client_id)
        self._ib: Any  = None

    def __enter__(self):
        if not _IB_AVAILABLE:
            raise RuntimeError("ib_insync is not installed")
        with _connect_lock:
            self._ib = IB()
            self._ib.connect(self.host, self.port, clientId=self.client_id, timeout=10)
            self._ib.sleep(0.5)
        return self

    def __exit__(self, *_):
        try:
            if self._ib and self._ib.isConnected():
                self._ib.disconnect()
        except Exception:
            pass
        self._ib = None

    # ── Live prices ────────────────────────────────────────────────────────────

    def get_live_prices(self, tickers: list[str]) -> dict[str, dict]:
        """Return {ticker: {"price": float, "prev_close": float}} for each ticker."""
        result: dict[str, dict] = {}
        if not self._ib:
            return result

        contracts = []
        ticker_map: dict[Any, str] = {}
        for sym in tickers:
            try:
                # OCC option symbol: 6+ char root + 6-digit date + C/P + 8-digit strike
                if re.match(r'^[A-Z]{1,6}\d{6}[CP]\d{8}$', sym):
                    root   = re.match(r'^([A-Z]+)', sym).group(1)
                    dstr   = sym[len(root):len(root)+6]
                    pc     = sym[len(root)+6]
                    strike = int(sym[len(root)+7:]) / 1000.0
                    expiry = "20" + dstr
                    right  = 'C' if pc == 'C' else 'P'
                    # Try SMART first (works for equity options); fall back to CBOE
                    # for cash-settled index options (SPX, VIX, NDX, RUT, etc.)
                    qualified = self._ib.qualifyContracts(
                        Option(root, expiry, strike, right, 'SMART')
                    )
                    if not qualified:
                        qualified = self._ib.qualifyContracts(
                            Option(root, expiry, strike, right, 'CBOE')
                        )
                else:
                    c = Stock(sym, 'SMART', 'USD')
                    qualified = self._ib.qualifyContracts(c)
                if qualified:
                    ticker_map[id(qualified[0])] = sym
                    contracts.append(qualified[0])
            except Exception:
                pass

        if not contracts:
            return result

        tickers_obj = self._ib.reqTickers(*contracts)
        for t in tickers_obj:
            sym = ticker_map.get(id(t.contract))
            if sym is None:
                sym = getattr(t.contract, 'symbol', None)
            if sym is None:
                continue
            price      = t.last if t.last and t.last > 0 else t.close
            prev_close = t.close
            result[sym] = {
                "price":      float(price)      if price      else None,
                "prev_close": float(prev_close) if prev_close else None,
            }
        return result

    # ── Account summary ────────────────────────────────────────────────────────

    def get_account_summary(self) -> dict:
        """Return account-level metrics: net_liquidation, cash, unrealized_pnl."""
        if not self._ib:
            return {}
        summary = self._ib.accountSummary()
        result: dict[str, float] = {}
        key_map = {
            "NetLiquidation":    "net_liquidation",
            "TotalCashValue":    "cash",
            "UnrealizedPnL":     "unrealized_pnl",
            "RealizedPnL":       "realized_pnl",
        }
        for item in summary:
            mapped = key_map.get(item.tag)
            if mapped:
                try:
                    result[mapped] = float(item.value)
                except (ValueError, TypeError):
                    pass
        return result

    # ── Trade executions ───────────────────────────────────────────────────────

    def get_executions(self, start_date: str) -> tuple[list[dict], list[str]]:
        """
        Return (rows, errors) where rows is a list of execution dicts from IB fills
        since start_date (ISO string) and errors lists any per-fill processing failures.
        Each row has: time, ticker, instrument_type, side, quantity, price,
                      expiration, strike, option_type, multiplier, leg_group.
        Note: reqExecutions only returns fills from the current TWS session.
        """
        if not self._ib:
            return [], []
        from ib_insync import ExecutionFilter  # type: ignore
        ef = ExecutionFilter()
        ef.time = start_date.replace("-", "")  # YYYYMMDD
        trades = self._ib.reqExecutions(ef)

        rows: list[dict] = []
        errors: list[str] = []
        for trade in trades:
            ex  = trade.execution
            con = trade.contract
            try:
                itype = _contract_type(con)
                rows.append({
                    "time":          str(ex.time),
                    "date":          str(ex.time)[:10],
                    "ticker":        con.symbol,
                    "instrument_type": itype,
                    "side":          "long" if ex.side == "BOT" else "short",
                    "quantity":      abs(float(ex.shares)),
                    "price":         float(ex.avgPrice),
                    "expiration":    con.lastTradeDateOrContractMonth if itype == "option" else None,
                    "strike":        float(con.strike) if itype == "option" else None,
                    "option_type":   "call" if con.right == "C" else "put" if itype == "option" else None,
                    "multiplier":    float(con.multiplier) if con.multiplier else 1.0,
                    "leg_group":     str(ex.permId) if ex.permId else None,
                    "perm_id":       ex.permId,
                    "exec_id":       ex.execId,
                })
            except Exception as e:
                label = getattr(con, "symbol", None) or getattr(ex, "execId", "unknown")
                errors.append(f"{label}: {e}")
        return rows, errors

    # ── Cash transactions ──────────────────────────────────────────────────────

    def get_cash_transactions(self, start_date: str) -> list[dict]:
        """
        Return deposits, withdrawals, dividends, and interest from IB
        since start_date (ISO string).
        """
        if not self._ib:
            return []
        try:
            # Flex query alternative: use statement of funds
            fund_stmts = self._ib.reqPnLSingle  # not the right call, use below
        except Exception:
            pass

        # IB doesn't expose cash transactions via the live API in a simple way.
        # We use the account ledger as a proxy.
        result: list[dict] = []
        try:
            positions = self._ib.portfolio()
            _ = positions  # not directly useful here
            summary   = self._ib.accountSummary()
            for item in summary:
                if item.tag in ("Deposits", "Withdrawals"):
                    try:
                        txn_type = item.tag.rstrip("s").lower()
                        result.append({
                            "date":        datetime.date.today().isoformat(),
                            "type":        txn_type,
                            "amount":      abs(float(item.value)),
                            "description": f"IB account {item.tag}",
                            "source":      "ib",
                        })
                    except Exception:
                        pass
        except Exception:
            pass
        return result

    # ── Greeks refresh ─────────────────────────────────────────────────────────

    def get_option_greeks(self, tickers_options: list[dict]) -> dict[int, dict]:
        """
        For a list of option trades [{trade_id, ticker, expiration, strike, option_type}],
        return {trade_id: {"delta": float, "theta": float}}.
        """
        if not self._ib:
            return {}
        result: dict[int, dict] = {}
        for item in tickers_options:
            try:
                root   = item["ticker"]
                expiry = str(item["expiration"]).replace("-", "")[:8]
                strike = float(item["strike"])
                right  = "C" if str(item.get("option_type", "")).upper().startswith("C") else "P"
                c = Option(root, expiry, strike, right, 'SMART')
                qualified = self._ib.qualifyContracts(c)
                if not qualified:
                    continue
                [ticker_obj] = self._ib.reqTickers(qualified[0])
                if ticker_obj.modelGreeks:
                    result[item["trade_id"]] = {
                        "delta": ticker_obj.modelGreeks.delta,
                        "theta": ticker_obj.modelGreeks.theta,
                    }
            except Exception:
                pass
        return result


# ── Flex Query (HTTP, no IB connection needed) ─────────────────────────────────

_FLEX_SEND_URL = (
    "https://ndcdyn.interactivebrokers.com"
    "/AccountManagement/FlexWebService/SendRequest"
    "?t={token}&q={query_id}&v=3"
)
_FLEX_GET_URL = "{url}?q={ref}&v=3"
_FLEX_HEADERS = {"User-Agent": "Mozilla/5.0"}


_FLEX_EMPTY = lambda err=None: {
    "account_summary": {"net_liquidation": 0.0, "cash": 0.0,
                        "total_deposits": 0.0, "total_withdrawals": 0.0},
    "cash_transactions": [], "trades": [], "error": err,
}


def fetch_flex_report(token: str, query_id: str) -> dict:
    """
    Fetch an IB Flex Query report and return structured data.

    IB's Flex Web Service requires >=10 s before the first GetStatement call.
    Rapid re-polls return 'Invalid request' (an anti-hammering guard, not a hard
    error), so we use exponential back-off: 10, 15, 20, 30, 45 s between attempts.
    """
    try:
        # Step 1 — trigger report generation
        req1 = urllib.request.Request(
            _FLEX_SEND_URL.format(token=token, query_id=query_id),
            headers=_FLEX_HEADERS,
        )
        with urllib.request.urlopen(req1, timeout=30) as resp:
            xml1 = resp.read().decode("utf-8")

        try:
            root1 = ET.fromstring(xml1)
        except ET.ParseError:
            return _FLEX_EMPTY(f"Could not parse step-1 response: {xml1[:300]}")

        status = root1.findtext("Status") or ""
        if status != "Success":
            msg = root1.findtext("ErrorMessage") or xml1[:300]
            return _FLEX_EMPTY(f"IB rejected the request: {msg}")

        ref_code = (root1.findtext("ReferenceCode") or "").strip()
        stmt_url  = (root1.findtext("Url") or "").strip()
        if not ref_code or not stmt_url:
            return _FLEX_EMPTY(f"No reference code in step-1 response: {xml1[:300]}")

        # Step 2 — poll with exponential back-off
        waits = [10, 15, 20, 30, 45]  # seconds between attempts, up to ~2 min total
        last_error = "Report not ready after all retries."
        for wait in waits:
            time.sleep(wait)
            step2_url = f"{stmt_url}?q={ref_code}&v=3"
            req2 = urllib.request.Request(step2_url, headers=_FLEX_HEADERS)
            with urllib.request.urlopen(req2, timeout=60) as resp:
                xml2 = resp.read().decode("utf-8")

            try:
                root2 = ET.fromstring(xml2)
            except ET.ParseError:
                last_error = f"Could not parse step-2 response: {xml2[:200]}"
                continue

            if root2.tag == "FlexQueryResponse":
                return _parse_flex_xml(xml2)

            s2      = root2.findtext("Status") or ""
            err_msg = root2.findtext("ErrorMessage") or ""

            # "Processing" or "Invalid request" (too-soon poll) — back off and retry
            if s2 == "Processing" or "invalid" in err_msg.lower():
                last_error = f"IB not ready ({s2}: {err_msg})"
                continue

            return _FLEX_EMPTY(f"IB Flex error: {err_msg or xml2[:300]}")

        return _FLEX_EMPTY(last_error)

    except Exception as exc:
        return _FLEX_EMPTY(str(exc))


def _yyyymmdd_to_iso(v: str) -> str:
    """Convert IB date string 'YYYYMMDD' or 'YYYYMMDD;HHmmss' to 'YYYY-MM-DD'."""
    s = str(v or "")[:8]
    if len(s) == 8 and s.isdigit():
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}"
    return s


def _parse_flex_xml(xml_text: str) -> dict:
    """Parse Flex Statement XML into account_summary + cash_transactions + trades."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        return {"account_summary": {}, "cash_transactions": [], "trades": [], "error": f"XML parse error: {e}"}

    # ── Account summary: use the last <ChangeInNAV endingValue="..."> ──────────
    # The query returns one FlexStatement per day; the last one is most recent.
    acct: dict = {"net_liquidation": 0.0, "cash": 0.0,
                  "total_deposits": 0.0, "total_withdrawals": 0.0}
    for node in root.iter("ChangeInNAV"):
        try:
            acct["net_liquidation"] = float(node.get("endingValue", 0) or 0)
        except (ValueError, TypeError):
            pass

    # ── Cash transactions ──────────────────────────────────────────────────────
    txns: list[dict] = []
    for node in root.iter("CashTransaction"):
        txn_type = node.get("type", "")
        if not txn_type:
            continue
        try:
            amount = float(node.get("amount", 0) or 0)
        except (ValueError, TypeError):
            amount = 0.0
        # Accumulate deposit/withdrawal totals
        tl = txn_type.lower()
        if "deposit" in tl:
            acct["total_deposits"] += max(amount, 0)
        if "withdrawal" in tl:
            acct["total_withdrawals"] += abs(min(amount, 0))

        raw_date = node.get("settleDate") or node.get("dateTime", "")
        txns.append({
            "date":        _yyyymmdd_to_iso(raw_date),
            "type":        txn_type,
            "amount":      amount,
            "currency":    node.get("currency", "USD"),
            "description": node.get("description", ""),
        })

    txns.sort(key=lambda x: x["date"], reverse=True)

    # ── Trades ─────────────────────────────────────────────────────────────────
    trades = parse_flex_trades(root)

    return {"account_summary": acct, "cash_transactions": txns, "trades": trades, "error": None}


def parse_flex_trades(root_or_xml) -> list[dict]:
    """
    Parse <Trade> elements from a Flex Statement (ET.Element or XML string).
    Uses openCloseIndicator ('O'/'C') to correctly identify entries and exits,
    including short positions (where BUY is the close, not the open).

    Returns a list of dicts compatible with add_trade() kwargs.
    """
    if isinstance(root_or_xml, str):
        try:
            root = ET.fromstring(root_or_xml)
        except ET.ParseError:
            return []
    else:
        root = root_or_xml

    from collections import defaultdict

    # Collect all fills with normalised fields
    fills: list[dict] = []
    for node in root.iter("Trade"):
        try:
            qty = float(node.get("quantity", 0) or 0)
            if qty == 0:
                continue
            price     = float(node.get("tradePrice", 0) or 0)
            commission = float(node.get("ibCommission", 0) or 0)
            fifo_pnl  = float(node.get("fifoPnlRealized", 0) or 0)
            put_call  = node.get("putCall", "") or ""
            asset_cat = (node.get("assetCategory") or "").upper()
            if asset_cat == "FUT":
                _instrument_type = "future"
            elif asset_cat == "FOP" or put_call:
                _instrument_type = "option"
            else:
                _instrument_type = "stock"
            fills.append({
                "date":            _yyyymmdd_to_iso(node.get("tradeDate", "")),
                "datetime":        node.get("dateTime", ""),
                "ticker":          node.get("underlyingSymbol", "") or node.get("symbol", ""),
                "instrument_type": _instrument_type,
                "side":            "long" if (node.get("buySell", "") == "BUY") else "short",
                "quantity":        abs(qty),
                "price":           price,
                "expiration":      _yyyymmdd_to_iso(node.get("expiry", "")) if node.get("expiry") else None,
                "strike":          float(node.get("strike") or 0) or None,
                "option_type":     "call" if put_call == "C" else "put" if put_call == "P" else None,
                "multiplier":      float(node.get("multiplier", 1) or 1),
                "open_close":      node.get("openCloseIndicator", "O"),  # 'O' or 'C'
                "commission":      commission,
                "fifo_pnl":        fifo_pnl,
                "trade_id":        node.get("tradeID", ""),
                "txn_type":        node.get("transactionType", ""),
            })
        except Exception:
            pass

    # Group by instrument key
    buckets: dict[str, list[dict]] = defaultdict(list)
    for f in sorted(fills, key=lambda x: x["datetime"]):
        key = "_".join([
            f["ticker"],
            str(f.get("expiration") or ""),
            str(f.get("strike") or ""),
            str(f.get("option_type") or ""),
        ])
        buckets[key].append(f)

    trades: list[dict] = []
    for key, bucket_fills in buckets.items():
        open_fills  = [f for f in bucket_fills if f["open_close"] == "O"]
        close_fills = [f for f in bucket_fills if f["open_close"] == "C"]

        if not open_fills:
            continue

        # Aggregate open fills → one entry (weighted-average price, sum qty)
        total_open_qty   = sum(f["quantity"] for f in open_fills)
        avg_open_price   = (sum(f["quantity"] * f["price"] for f in open_fills) / total_open_qty
                            if total_open_qty else 0)
        open_commission  = sum(f["commission"] for f in open_fills)
        open_side        = open_fills[0]["side"]  # long or short
        entry_date       = open_fills[0]["date"]
        first_fill       = open_fills[0]

        # Aggregate close fills → one exit (if any)
        exit_date  = None
        exit_price = None
        if close_fills:
            total_close_qty  = sum(f["quantity"] for f in close_fills)
            avg_close_price  = (sum(f["quantity"] * f["price"] for f in close_fills) / total_close_qty
                                if total_close_qty else 0)
            close_commission = sum(f["commission"] for f in close_fills)
            exit_date        = close_fills[-1]["date"]
            exit_price       = avg_close_price
        else:
            close_commission = 0.0

        total_commission = open_commission + close_commission
        notes_parts = [f"Imported via Flex Query"]
        if total_commission:
            notes_parts.append(f"Commission: ${total_commission:.4f}")
        if close_fills:
            fifo = sum(f["fifo_pnl"] for f in close_fills)
            if fifo:
                notes_parts.append(f"FIFO P&L: ${fifo:.2f}")

        trades.append({
            "entry_date":      _to_date(entry_date),
            "ticker":          first_fill["ticker"],
            "quantity":        total_open_qty,
            "entry_price":     round(avg_open_price, 6),
            "exit_date":       _to_date(exit_date),
            "exit_price":      round(exit_price, 6) if exit_price is not None else None,
            "notes":           " | ".join(notes_parts),
            "stop_enabled":    False,
            "opening_stop":    None,
            "current_stop":    None,
            "tag_ids":         [],
            "instrument_type": first_fill["instrument_type"],
            "expiration":      first_fill["expiration"],
            "strike":          first_fill["strike"],
            "option_type":     first_fill["option_type"],
            "multiplier":      first_fill["multiplier"],
            "side":            open_side,
            "leg_group":       None,
            "leg_label":       None,
        })

    # Auto-group option legs that share the same underlying + entry_date + expiration
    # (these are almost certainly legs of the same spread entered on the same day)
    from collections import defaultdict as _dd
    import uuid as _uuid2
    spread_buckets: dict[tuple, list[int]] = _dd(list)
    for i, t in enumerate(trades):
        if t["instrument_type"] == "option" and t.get("expiration"):
            key = (t["ticker"], str(t.get("entry_date") or ""), str(t["expiration"]))
            spread_buckets[key].append(i)

    for key, indices in spread_buckets.items():
        if len(indices) < 2:
            continue
        grp = str(_uuid2.uuid4())[:8]
        for i in indices:
            t = trades[i]
            side_str  = "Long" if t["side"] == "long" else "Short"
            opt_str   = "Call" if str(t.get("option_type") or "").lower().startswith("c") else "Put"
            strike    = t.get("strike") or 0
            t["leg_group"] = grp
            t["leg_label"] = f"{side_str} {opt_str} ${strike:.2f}"

    return trades


# ── Helpers ────────────────────────────────────────────────────────────────────

def _contract_type(con) -> str:
    t = getattr(con, "secType", "STK")
    return {"STK": "stock", "OPT": "option", "FUT": "future"}.get(t, "stock")


def test_connection(host: str, port: int, client_id: int = 1) -> tuple[bool, str]:
    """Return (success, message). Safe to call from Streamlit."""
    if not _IB_AVAILABLE:
        return False, "ib_insync is not installed. Run: pip install ib_insync nest_asyncio"
    try:
        with IBClient(host, port, client_id):
            return True, "Connected to IB Gateway / TWS successfully."
    except Exception as e:
        return False, f"Connection failed: {e}"


def _to_date(v):
    """Convert IB date string to datetime.date, or return None."""
    if v is None:
        return None
    try:
        import pandas as pd
        return pd.to_datetime(str(v)[:10]).date()
    except Exception:
        return None


def parse_ib_executions_to_trades(executions: list[dict]) -> list[dict]:
    """
    Match BOT/SLD pairs from IB executions into open/close trade records.
    Groups by ticker + expiration + strike + option_type.
    Returns list of dicts compatible with add_trade() kwargs.
    """
    from collections import defaultdict
    import uuid as _uuid

    # Group by instrument identity
    buckets: dict[str, list[dict]] = defaultdict(list)
    for ex in sorted(executions, key=lambda x: x["time"]):
        key = "_".join([
            ex["ticker"],
            str(ex.get("expiration") or ""),
            str(ex.get("strike") or ""),
            str(ex.get("option_type") or ""),
        ])
        buckets[key].append(ex)

    trades: list[dict] = []
    for key, fills in buckets.items():
        open_fills: list[dict]  = []
        close_fills: list[dict] = []
        for f in fills:
            if f["side"] == "long":
                open_fills.append(f)
            else:
                close_fills.append(f)

        # Pair opens with closes
        used_closes: set[int] = set()
        for i, op in enumerate(open_fills):
            matched_close: dict | None = None
            for j, cl in enumerate(close_fills):
                if j not in used_closes and cl["date"] >= op["date"] and abs(cl["quantity"] - op["quantity"]) < 0.001:
                    matched_close = cl
                    used_closes.add(j)
                    break
            leg_group = str(op.get("leg_group") or _uuid.uuid4())
            trade = {
                "entry_date":      _to_date(op["date"]),
                "ticker":          op["ticker"],
                "quantity":        op["quantity"],
                "entry_price":     op["price"],
                "exit_date":       _to_date(matched_close["date"])  if matched_close else None,
                "exit_price":      matched_close["price"] if matched_close else None,
                "notes":           f"Imported from IB (execId: {op.get('exec_id', '')})",
                "stop_enabled":    False,
                "opening_stop":    None,
                "tag_ids":         [],
                "current_stop":    None,
                "instrument_type": op["instrument_type"],
                "expiration":      op.get("expiration"),
                "strike":          op.get("strike"),
                "option_type":     op.get("option_type"),
                "multiplier":      op.get("multiplier", 1.0),
                "leg_group":       leg_group,
                "leg_label":       f"Leg {i + 1}",
                "side":            op["side"],
            }
            trades.append(trade)
    return trades
